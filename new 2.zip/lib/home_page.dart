import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  String token = "";
  HomePage({required this.token});

  var subStatus =  "";
  var response;
  getInfo() async {
    var dio = Dio();
    try {
      response = await dio.get('http://localhost:3000/getinfo', options: Options(
        headers: {
          "Authorization": "Bearer $token"
        }

      ));
      print(response);
    } catch (e) {
      print(e);
    }
  }





  @override
  Widget build(BuildContext context) {
  subStatus = response.data['subscriptionStatus'].toString();
    return  MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            children:  [
              Text(subStatus),
            ],
          ),
        ),
      ),
    );
  }
}
