class Urls {

  static String verifyUser = "localhost:3000/verifyUser";
}